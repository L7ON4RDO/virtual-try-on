const personInput = document.getElementById("personInput");
const clothInput = document.getElementById("clothInput");
const tryonBtn = document.getElementById("tryonBtn");
const result = document.getElementById("result");
const resultImg = document.getElementById("resultImg");
const progressContainer = document.getElementById("progress-container");
const progressBar = document.querySelector(".progress-bar");
const downloadBtn = document.getElementById("downloadBtn");

let personId = null;
let clothId = null;
let progressInterval = null;

async function uploadImage(file, type) {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("type", type);

  const res = await fetch("http://localhost:5000/api/upload", {
    method: "POST",
    body: formData,
  });

  const data = await res.json();
  return data.id;
}

personInput.addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (file) {
    personId = await uploadImage(file, "person");
    checkReady();
  }
});

clothInput.addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (file) {
    clothId = await uploadImage(file, "cloth");
    checkReady();
  }
});

function checkReady() {
  tryonBtn.disabled = !(personId && clothId);
}

function simulateProgress() {
  let width = 0;
  if (progressInterval) clearInterval(progressInterval);

  progressInterval = setInterval(() => {
    if (width >= 95) return;
    width += Math.random() * 5;
    if (width > 95) width = 95;
    progressBar.style.width = width + "%";
  }, 700);
}

function cleanupProgress() {
  if (progressInterval) clearInterval(progressInterval);
  progressBar.style.width = "100%";
  progressContainer.classList.add("hidden");
}

tryonBtn.addEventListener("click", async () => {
  result.classList.add("hidden");
  progressContainer.classList.remove("hidden");
  progressBar.style.width = "0%";
  simulateProgress();

  try {
    const initRes = await fetch("http://localhost:5000/api/tryon", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ person_id: personId, cloth_id: clothId }),
    });

    const task = await initRes.json();
    if (!task.task_id) {
      alert("Erro 1: Não foi possível iniciar a tarefa (sem task_id).");
      cleanupProgress();
      return;
    }

    let status = task.status;
    let finalUrl = task.result_url || "";

    if (status === "COMPLETED" && finalUrl) {
      cleanupProgress();
      resultImg.src = finalUrl;
      result.classList.remove("hidden");
      return;
    }

    while (status === "PROCESSING") {
      await new Promise((r) => setTimeout(r, 4000));

      const checkRes = await fetch("http://localhost:5000/api/tryon", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task_id: task.task_id }),
      });

      const checkData = await checkRes.json();
      status = checkData.status;

      if (status === "COMPLETED") {
        finalUrl = checkData.result_url;
      } else if (status === "FAILED") {
        alert("Erro 2: A geração da imagem falhou no Replicate.");
        break;
      }
    }

    cleanupProgress();

    if (finalUrl) {
      console.log("URL recebida no frontend:", finalUrl);
      resultImg.src = finalUrl;
      result.classList.remove("hidden");

      downloadBtn.classList.remove("hidden");
      downloadBtn.onclick = () => {
        const link = document.createElement("a");
        link.href = finalUrl;
        link.download = "camisa-gerada.png";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      };
    } else {
      alert("Erro 3: Não foi possível obter a URL da imagem de resultado.");
    }

  } catch (error) {
    console.error("Erro geral no Try-On:", error);
    alert("Erro 4: Ocorreu um erro de rede ou conexão durante o processo.");
    cleanupProgress();
  }
});
